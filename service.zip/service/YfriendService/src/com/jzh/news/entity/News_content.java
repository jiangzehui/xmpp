package com.jzh.news.entity;

public class News_content {
	private int cid;
	private String ctype;
	private String ctitle;
	private String czhaiyao;
	private String cimage;
	private String cauthor;
	private String ccontent;
	private String ctime;
	private String cpinglun;

	public String getCpinglun() {
		return cpinglun;
	}

	public void setCpinglun(String cpinglun) {
		this.cpinglun = cpinglun;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCtype() {
		return ctype;
	}

	public void setCtype(String ctype) {
		this.ctype = ctype;
	}

	public String getCtitle() {
		return ctitle;
	}

	public void setCtitle(String ctitle) {
		this.ctitle = ctitle;
	}

	public String getCzhaiyao() {
		return czhaiyao;
	}

	public void setCzhaiyao(String czhaiyao) {
		this.czhaiyao = czhaiyao;
	}

	public String getCimage() {
		return cimage;
	}

	public void setCimage(String cimage) {
		this.cimage = cimage;
	}

	public String getCauthor() {
		return cauthor;
	}

	public void setCauthor(String cauthor) {
		this.cauthor = cauthor;
	}

	public String getCcontent() {
		return ccontent;
	}

	public void setCcontent(String ccontent) {
		this.ccontent = ccontent;
	}

	public String getCtime() {
		return ctime;
	}

	public void setCtime(String ctime) {
		this.ctime = ctime;
	}

	public News_content() {
		super();
		// TODO Auto-generated constructor stub
	}

}
